/*
 * blinky.h
 *
 *  Created on: Dec 10, 2013
 *      Author: kjell
 */

#ifndef BLINKY_H_
#define BLINKY_H_

#define BLINKY_STACK_SIZE	128

extern void startBlinkyRed(void);
extern void startBlinkyGreen(void);

#endif /* BLINKY_H_ */

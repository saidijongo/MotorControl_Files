/*
 * obldc_can.h
 *
 *  Created on: 27.04.2015
 *      Author: joerg
 */

#ifndef OBLDC_CAN_H_
#define OBLDC_CAN_H_

void obldc_can_init(void);

#endif /* OBLDC_CAN_H_ */

# MircroProject
~ USART Interaction with Atmega16 and Qt Application
